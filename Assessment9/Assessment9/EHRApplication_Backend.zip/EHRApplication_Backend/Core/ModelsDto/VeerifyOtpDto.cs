﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Core.ModelsDto
{
    public class VeerifyOtpDto
    {
        public string UserName { get; set; }
        public int Otp {  get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models.User
{
    public  class Specialisation
    {
        public int Id { get; set; }
        public string SpecialisationType { get; set; }
    }
}
